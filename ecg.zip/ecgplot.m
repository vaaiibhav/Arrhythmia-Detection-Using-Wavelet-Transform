load('ecg');
plot(val(1,:));